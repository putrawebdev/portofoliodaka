<!-- jQuery first, then Popper.js, then Bootstrap JS -->
		<script src="assets/js/jquery-min.js"></script>
		<script src="assets/js/popper.min.js"></script>
		<script src="assets/js/bootstrap.min.js"></script>
		<script src="assets/js/modernizr-2.8.3.min.js"></script>
		<script src="assets/js/particles.min.js"></script>
		<script src="assets/js/app.js"></script>
		<script src="assets/js/jquery.nav.js"></script>
		<script src="assets/js/smooth-scroll.js"></script>
		<script src="assets/js/owl.carousel.min.js"></script>
		<script src="assets/js/jquery.mixitup.js"></script>
		<script src="assets/js/animated-headline.js"></script>
		<script src="assets/js/jquery.counterup.min.js"></script>
		<script src="assets/js/waypoints.min.js"></script>
		<script src="assets/js/wow.js"></script>
		<script src="assets/js/jquery.easing.min.js"></script>  
		<script src="assets/js/nivo-lightbox.js"></script>
		<script src="assets/js/form-contact.js"></script>
		<script src="assets/js/main.js"></script>
		